#include <math.h>
#include <matrix.h>
#include <mex.h>
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  mexPrintf("Hello World!\n");
}
- See more at: http://www.shawnlankton.com/2008/03/getting-started-with-mex-a-short-tutorial/#sthash.XZ0RinKv.dpuf